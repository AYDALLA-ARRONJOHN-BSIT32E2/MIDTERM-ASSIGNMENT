﻿// User.cs (Domain layer)
public class User
{
    public string Username { get; set; }
    public string PasswordHash { get; set; }
    public string Email { get; set; }
}
