﻿using System.ComponentModel.DataAnnotations;

namespace Midterm_Assignment_login.Models
{
    public class LoginViewModel
    {
        [Required]
        public string Username { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
